package com.example.simplecalci;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    TextInputEditText edt1, edt2;
    TextView resultText;
    MaterialButton buttonSum, buttonSub, buttonMul, buttonDiv, buttonClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edt1 = findViewById(R.id.edittext1);
        edt2 = findViewById(R.id.edittext2);
        resultText = findViewById(R.id.editText3);

        buttonSum = findViewById(R.id.btnSum);
        buttonSub = findViewById(R.id.btnSub);
        buttonMul = findViewById(R.id.btnMul);
        buttonDiv = findViewById(R.id.btnDiv);
        buttonClear = findViewById(R.id.btnClear);


        buttonSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation("add");
            }
        });

        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation("subtract");
            }
        });

        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation("multiply");
            }
        });

        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performOperation("divide");
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearAll();
            }
        });
    }

    private void performOperation(String operation) {
        String sNum1 = edt1.getText().toString().trim();
        String sNum2 = edt2.getText().toString().trim();

        if (sNum1.isEmpty() || sNum2.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please enter both numbers",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double number1 = Double.parseDouble(sNum1);
            double number2 = Double.parseDouble(sNum2);
            double result = 0;

            switch (operation) {
                case "add":
                    result = number1 + number2;
                    break;
                case "subtract":
                    result = number1 - number2;
                    break;
                case "multiply":
                    result = number1 * number2;
                    break;
                case "divide":
                    if (number2 != 0) {
                        result = number1 / number2;
                    } else {
                        Toast.makeText(getApplicationContext(), "Cannot divide by zero",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    break;
            }

            if (result == (long) result) {
                resultText.setText(String.valueOf((long) result));
            } else {
                resultText.setText(String.format("%.2f", result));
            }

        } catch (NumberFormatException e) {
            Toast.makeText(getApplicationContext(), "Please enter valid numbers",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void clearAll() {
        edt1.getText().clear();
        edt2.getText().clear();
        resultText.setText("0");
    }
}